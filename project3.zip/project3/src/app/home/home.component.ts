import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  title = 'Welcome to the world class GYM';
  name= 'Bangalore Gym'
  title1='We offer world class facility to your service to make up you healthy';

}
