import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http"
// import { map } from 'rxjs/operators'
@Injectable({
  providedIn: 'root'
})
export class MobileService {

  constructor(private http:HttpClient) {}
  url : any = "http://fakestoreapi.com/products"
  fetchMobiles(){
    return this.http.get(this.url)
  }
  delete(id:any){
    return this.http.delete(this.url+"/"+id)
  }
}
