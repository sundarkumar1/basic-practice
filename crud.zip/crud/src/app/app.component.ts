import { Component,OnInit} from '@angular/core';
import { MobileService } from './mobile.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'crud';
  constructor(private ms : MobileService)
  {

  }
  products:any
  ngOnInit()
  {
    this.getMobiles()
  }
  getMobiles(){ 
    this.ms.fetchMobiles().subscribe(
    (data)=>{
      this.products = data
    },
    (error)=>{
      console.log(error)
    }
    )
  }


  delete(id:any){
    this.ms.delete(id).subscribe(
      (res)=>{
        this.getMobiles()
      }
    )
  }
}






